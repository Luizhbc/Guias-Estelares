// Verificar se o texto contém a palavra Amor

let phrase = 'Eu quero viver o Amor!'
phrase = phrase.toUpperCase()
//Passei toda a frase para maiusculo, quando puder fazer isso com o termo buscado também
console.log(phrase.includes('AMOR'))
