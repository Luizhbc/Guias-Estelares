// Manipulando Strings e Números

// Transformar Strings em Número e Número em String

let string = '123'
console.log(Number(string))
//Números no console.log são azuis
let number = 321
console.log(String(number))
//Strings são brancas
