/*

    Prototype

    * Prototype-based language
    * Prototype chain
    * __proto__

*/

'string'.__proto__
//strings
;(23.0).__proto__
//Números (colocar . depois)
true.__proto__
//boolean
