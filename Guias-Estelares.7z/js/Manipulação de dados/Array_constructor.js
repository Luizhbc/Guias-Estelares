// Criar Array com construtor
let myArray = new Array(10)
//let myArray = new Array('a', 'b', 'c')
console.log(myArray)
