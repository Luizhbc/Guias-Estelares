// Transformar uma cadeia de caracteres em elementos de um array

let word = 'manipulação'
console.log(Array.from(word))
