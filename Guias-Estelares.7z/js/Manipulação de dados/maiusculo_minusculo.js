// Transformando letras minúsculas em maiúsculas. Ao contrário disso também

let word =
  'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique voluptates assumenda a nesciunt earum quia, aspernatur minus, at ipsa voluptatum animi incidunt porro laboriosam neque doloribus molestias voluptas asperiores excepturi.'
//word = word.toUpperCase()
//word = word.toLowerCase()
console.log(word)
//console.log(word.toUpperCase())
//console.log(word.toLowerCase())

//posso atrelar quantos metodos quiser
