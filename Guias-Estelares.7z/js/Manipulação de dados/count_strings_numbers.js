// Manipulando Strings e Números

// Contar quantos caracteres tem uma palavra e quantos dígitos tem um número

let word = 'Otorrinolaringologista'
console.log(word.length)
let number = 1234
console.log(number.length)
//undefined
console.log(String(number.length))
