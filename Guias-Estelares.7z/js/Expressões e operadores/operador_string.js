//  comparation 
//console.log( 'a' == 'a') //true

// concatenation (concatenação)
// Retorna a união de duas Strings

let alpha = 'alpha'
alpha += 'bet'
//bet adicionado ao alpha
console.log(alpha)

