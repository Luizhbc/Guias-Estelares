let pao = false
let queijo = false


// E / OU / NAO
// && / || / !