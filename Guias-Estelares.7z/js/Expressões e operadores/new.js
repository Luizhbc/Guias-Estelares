/*
  new

  *left-hand-side expression
  *criar um novo objeto
*/

let name = new String('jhon')
name.surName = 'Silva'
let age = new Number(23)
console.log(name, age)

let date = new Date('2021-10-21')
console.log(date)
