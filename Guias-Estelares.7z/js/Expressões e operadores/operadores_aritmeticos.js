// multiplicação *
// console.log(2*5)

//divisão /
// console.log(10/2)

//soma +
//console.log(2+2)

//resto divisão
// let remainder //resto inglês
// remainder = 11 % 11
// console.log(remainder)

//incremento ++
//let increment = 0
//increment++
//console.log(++increment) /nota increment++ para incrementar depois

//decremento
// let decrement = 0
// console.log(decrement)
// mesmo esquema do incremento

//exponencial **
//console.log(3 ** 3)
