let = 5
let -=5
console.log(let)