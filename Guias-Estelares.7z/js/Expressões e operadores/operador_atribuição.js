let x

//assignment
x = 1

//addition assignment
// x = x + 2  
x += 2

//subtraction assignment
//x = x - 2
x -= 2

//multiplication assignment
// x = x * 2
x *= 2

//division
// x = x / 2
x /= 2

//remainder, exponetiation
x %= 2
x **= 2