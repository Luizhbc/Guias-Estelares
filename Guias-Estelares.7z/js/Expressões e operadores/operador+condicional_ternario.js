//condição então valor 1 se não valor 2
//condition ? value1 : value2

//exemplos
//café da manha top

let pao = false
let queijo = false

const niceBreakFast = pao && queijo ? 'café top' : 'café ruim'
console.log(niceBreakFast)

//

let age = 19
const canDrive = age >= 18 ? 'pode dirigir' : 'não pode dirigir'
console.log(canDrive)