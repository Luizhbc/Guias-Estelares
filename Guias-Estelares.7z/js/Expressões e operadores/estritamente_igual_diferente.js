let one = 1
let two = 2

// === estritamente igual a
console.log( one === "1")
console.log( one === 1)
