/*
  Operadores unários
  typeof
  delete
*/

const person = {
  name: 'jhon',
  age: 30
}
delete person.age
console.log(person)
// varre procurando uma propriedade para deletar