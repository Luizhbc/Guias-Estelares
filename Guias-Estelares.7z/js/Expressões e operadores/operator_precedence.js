/* 
    Operator Precedence
        precedência de operadores

    *Grouping  ()
    *negação e incremento ! ++  --
    *  * e /
    *  + e -
    *  <  <=  >  >=
    *  ==  !=  === !===
    *  &&
    *  ||
    *  ?:
    *  = += -= *=
*/

