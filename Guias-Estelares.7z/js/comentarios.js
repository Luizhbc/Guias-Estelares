//aula1
console.log('Bem vindo') //comentario em linha
// pode ser usado para ignorar codigos

/*

  comentario em bloco

*/

//aula2

/*
;('') // aspas duplas
'' // aspas simples
`` // template liratal or template strings
console.log(`Luiz ${10 % 3}`)
*/

//aula3

/*
  * number
33 // inteiros
12.5 // reias - float
NaN // not a number
Infinity // infinito

*/

//aula4
/*
boolean <- logico
console.(false)

*/
/*
//aula5
 *undefined
 *null

*/
/*


//aula6 OBJECT
  *objeto
  *propriedades/atributos
  *funcionalidades / metodos

  {propriedade: "valor"}
 
 
//  console.log({
  name: "Luiz",
  idade: "27",
  andar: function () {
    console.log('andar')
}
})

//aula7
  *array (vetor) "ex:N: vetor[1..2] de inteiro"

  console.log([
    "leite",
    "ovos",
    2,
    1
  ])

  //
/*
// aula 8
tipos de dados

  data types
    *primitive/primitive value
    *strctural
    *structural primitive

  ## primitivos

    *String
    *Number
    *Boolean
    *Undefined
    *Symbol
    *Bigint

  ## estruturais
    *object
      *Array
      *Map
      *Set
      *Date
  
      ## primitivo estrutural / structural boot primitive

      *null

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects


*/
/*
 //Aula9
  var - escopo global
  let - escopo local
  const- imutavel / local


  <script>
  //var
  var clima = 'Quente'
  clima = 'frio' //recebendo clima
  console.log(clima)
</script>

<script>
  let tempo = true //boolean
  //tempo = '' // string

  console.log(typeof tempo)
</script>


testes de escopo
<script>
  let x = 20
  {
    let x = 10
    console.log(x)
  }
  console.log(x)
</script>


*/
