// function arrow
let name1 = 'luiz'
// const SayMyName = function () {}
// Substituo Function por =() => {}
const SayMyName = () => {
  console.log(name1)
}

SayMyName()
