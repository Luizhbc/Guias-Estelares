/*

    Prototype

    * Prototype-based language
    * Prototype chain
    * __proto__

*/
