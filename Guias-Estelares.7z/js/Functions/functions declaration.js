// Declaration - declração da função
// Funtion statement
function createPhrases() {
  console.log('Bom dia')
  console.log('boa tarde')
  console.log('Boa noite')
}

// Executar a função
// Rodar, chamar, invocar
// execute, run, call, invoke

createPhrases()

console.log('Fim do programa')
